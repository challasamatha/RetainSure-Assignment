from app import create_app

def test_shorten_url():
    app = create_app()
    client = app.test_client()

    res = client.post("/api/shorten", json={"url": "https://example.com"})
    assert res.status_code == 201
    data = res.get_json()
    assert "short_code" in data
    assert data["short_url"].startswith("http://localhost:5000/")
