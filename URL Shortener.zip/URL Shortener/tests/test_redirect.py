from app import create_app
from app.models import url_store

def test_redirect():
    app = create_app()
    client = app.test_client()

    # Pre-insert URL
    code = "abc123"
    url_store[code] = {"url": "https://example.com", "created_at": __import__('datetime').datetime.utcnow(), "clicks": 0}

    res = client.get(f"/{code}", follow_redirects=False)
    assert res.status_code == 302
    assert res.location == "https://example.com"
