from app import create_app
from app.models import url_store
from datetime import datetime

def test_stats():
    app = create_app()
    client = app.test_client()

    code = "xyz789"
    url_store[code] = {
        "url": "https://google.com",
        "created_at": datetime.utcnow(),
        "clicks": 3
    }

    res = client.get(f"/api/stats/{code}")
    assert res.status_code == 200
    data = res.get_json()
    assert data["url"] == "https://google.com"
    assert data["clicks"] == 3
    assert "created_at" in data
