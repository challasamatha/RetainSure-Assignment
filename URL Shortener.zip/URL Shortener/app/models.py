from datetime import datetime

# In-memory database
url_store = {}  # { short_code: { url, created_at, clicks } }
