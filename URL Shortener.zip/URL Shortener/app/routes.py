from flask import Blueprint, request, jsonify, redirect
from app.utils import is_valid_url, generate_short_code
from app.models import url_store
from datetime import datetime

bp = Blueprint('routes', __name__)

@bp.route('/')
def health():
    return {"status": "ok"}

@bp.route('/api/shorten', methods=['POST'])
def shorten_url():
    data = request.get_json()
    long_url = data.get("url")

    if not long_url or not is_valid_url(long_url):
        return jsonify({"error": "Invalid URL"}), 400

    # Generate unique short code
    while True:
        short_code = generate_short_code()
        if short_code not in url_store:
            break

    url_store[short_code] = {
        "url": long_url,
        "created_at": datetime.utcnow(),
        "clicks": 0
    }

    return jsonify({
        "short_code": short_code,
        "short_url": f"http://localhost:5000/{short_code}"
    }), 201

@bp.route('/<short_code>', methods=['GET'])
def redirect_url(short_code):
    entry = url_store.get(short_code)
    if not entry:
        return jsonify({"error": "Short URL not found"}), 404

    entry["clicks"] += 1
    return redirect(entry["url"], code=302)

@bp.route('/api/stats/<short_code>', methods=['GET'])
def stats(short_code):
    entry = url_store.get(short_code)
    if not entry:
        return jsonify({"error": "Short code not found"}), 404

    return jsonify({
        "url": entry["url"],
        "clicks": entry["clicks"],
        "created_at": entry["created_at"].isoformat()
    })
