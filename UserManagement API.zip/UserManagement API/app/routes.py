from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app import schemas, crud
from app.database import SessionLocal, get_db

router = APIRouter()

@router.get("/")
def health_check():
    return {"status": "ok"}

@router.post("/users", response_model=schemas.UserOut)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    if crud.get_user_by_email(db, user.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    return crud.create_user(db, user)

@router.get("/users", response_model=list[schemas.UserOut])
def read_users(db: Session = Depends(get_db)):
    return crud.get_users(db)

@router.get("/user/{user_id}", response_model=schemas.UserOut)
def read_user(user_id: int, db: Session = Depends(get_db)):
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@router.delete("/user/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db)):
    if not crud.delete_user(db, user_id):
        raise HTTPException(status_code=404, detail="User not found")
    return {"detail": "User deleted"}

@router.put("/user/{user_id}", response_model=schemas.UserOut)
def update_user(user_id: int, updated: schemas.UserCreate, db: Session = Depends(get_db)):
    user = crud.update_user(db, user_id, updated)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@router.get("/search")
def search_user(name: str, db: Session = Depends(get_db)):
    users = crud.get_users(db)
    return [u for u in users if name.lower() in u.name.lower()]

@router.post("/login")
def login(user: schemas.UserLogin, db: Session = Depends(get_db)):
    authenticated = crud.authenticate_user(db, user.email, user.password)
    if not authenticated:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return {"message": "Login successful", "user_id": authenticated.id}
