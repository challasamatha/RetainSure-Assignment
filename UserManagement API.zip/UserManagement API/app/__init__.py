from app import models
from app.database import engine

print("Creating database...")
models.Base.metadata.create_all(bind=engine)
print("Done.")
