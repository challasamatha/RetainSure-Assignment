# CHANGES.md

## 🔍 Issues Identified
- Passwords were stored in plaintext.
- No input validation.
- Global code with no modular separation.
- Insecure login logic.
- No error handling or status codes.

## ✅ Changes Made
- Used FastAPI for validation and routing.
- Modularized code: `crud`, `auth`, `routes`, `schemas`, `models`.
- Hashed passwords using `bcrypt`.
- Added proper HTTP error handling.
- Used SQLAlchemy ORM with SQLite.
- Added test coverage with `pytest`.

## ⚖️ Trade-offs
- Did not implement JWT auth due to time.
- Used SQLite instead of PostgreSQL for simplicity.

## 🤖 AI Tools Used
- ChatGPT to draft file structure and FastAPI route examples.
